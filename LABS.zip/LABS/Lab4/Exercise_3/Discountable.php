<?php
interface Discountable {
    public function getDiscount();
}
?>
