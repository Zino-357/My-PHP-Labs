<?php
require_once 'Book.php';
require_once 'Electronics.php';

// Polymorphism in action
$items = [];

$items[] = new Book("To Kill a Mockingbird", 18.00, "Harper Lee", 1960, "Classic",  1991);
$items[] = new Electronics("Smartphone", 300.00, "Samsung");

foreach ($items as $item) {
    $item->displayProduct();
    echo "Discount: $" . number_format($item->getDiscount(), 2) . "<br><br>";
}
?>
