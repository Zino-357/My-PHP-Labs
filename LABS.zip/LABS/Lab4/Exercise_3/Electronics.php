<?php
require_once 'Product.php';
require_once 'Discountable.php';

class Electronics extends Product implements Discountable {
    public $brand;

    public function __construct($product_name, $product_price, $brand) {
        parent::__construct($product_name, $product_price);
        $this->brand = $brand;
    }

    public function displayProduct() {
        echo "<h3>Electronics Information</h3>";
        echo "Product: " . $this->product_name . "<br>";
        echo "Price: $" . number_format($this->product_price, 2) . "<br>";
        echo "Brand: " . $this->brand . "<br>";
    }

    public function getDiscount() {
        // 15% discount for electronics
        return $this->product_price * 0.15;
    }
}
?>
