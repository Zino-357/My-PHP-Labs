<?php
require_once 'Book.php';

// Create a Book object
$book1 = new Book("Things Fall Apart", "Chinua Achebe", 1958, "Historical Fiction", 15.99);

// Call the method to display book information
$book1->displayBookInfo();
?>
