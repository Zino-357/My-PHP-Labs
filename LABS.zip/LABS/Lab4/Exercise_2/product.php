<?php
class Product {
    public $product_name;
    public $product_price;

    public function __construct($product_name, $product_price) {
        $this->product_name = $product_name;
        $this->product_price = $product_price;
    }

    public function displayProduct() {
        echo "<h3>Product Information</h3>";
        echo "Product Name: " . $this->product_name . "<br>";
        echo "Product Price: $" . number_format($this->product_price, 2) . "<br>";
    }
}
?>
