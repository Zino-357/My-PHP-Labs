<?php
require_once 'Product.php';

class Book extends Product {
    public $author;
    public $publication_year;
    public $genre;

    public function __construct($product_name, $product_price, $author, $publication_year, $genre) {
        parent::__construct($product_name, $product_price);
        $this->author = $author;
        $this->publication_year = $publication_year;
        $this->genre = $genre;
    }

    public function displayProduct() {
        echo "<h3>Book Information</h3>";
        echo "Title: " . $this->product_name . "<br>";
        echo "Price: $" . number_format($this->product_price, 2) . "<br>";
        echo "Author: " . $this->author . "<br>";
        echo "Publication Year: " . $this->publication_year . "<br>";
        echo "Genre: " . $this->genre . "<br>";
    }
}
?>
