<?php
require_once 'Product.php';
require_once 'Book.php';

// Creating a Product object
$product = new Product("Generic Notebook", 5.99);
$product->displayProduct();

echo "<hr>";

// Creating a Book object (inherits from Product)
$book = new Book("1984", 12.50, "George Orwell", 1949, "Dystopian");
$book->displayProduct();
?>
