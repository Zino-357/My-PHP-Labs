<?php
// process_form.php

// DB connection
$conn = new mysqli("localhost", "root", "", "WebAppDB");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate and sanitize inputs
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$age = (int)$_POST['age'];

if (empty($name) || empty($email) || empty($age)) {
    die("All fields are required.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format.");
}

// Prepare and insert into DB
$stmt = $conn->prepare("INSERT INTO Users (name, email, age) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $name, $email, $age);

if ($stmt->execute()) {
    echo "User added successfully! <br><a href='view_users.php'>View Users</a>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
