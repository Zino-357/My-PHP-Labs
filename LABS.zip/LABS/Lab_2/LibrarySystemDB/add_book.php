<?php
// add_book.php
$conn = new mysqli("localhost", "root", "", "LibrarySystemDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$authors = $conn->query("SELECT * FROM Authors");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Book</title>
</head>
<body>
    <h2>Add New Book</h2>
    <form method="POST" action="process_book.php">
        <label for="book_title">Book Title:</label><br>
        <input type="text" id="book_title" name="book_title" required><br><br>

        <label for="author_id">Author:</label><br>
        <select id="author_id" name="author_id" required>
            <option value="">Select Author</option>
            <?php while ($row = $authors->fetch_assoc()) { ?>
                <option value="<?= $row['author_id'] ?>"><?= htmlspecialchars($row['author_name']) ?></option>
            <?php } ?>
        </select><br><br>

        <label for="genre">Genre:</label><br>
        <input type="text" id="genre" name="genre" required><br><br>

        <label for="price">Price:</label><br>
        <input type="number" id="price" name="price" step="0.01" required><br><br>

        <input type="submit" value="Add Book">
    </form>
</body>
</html>
