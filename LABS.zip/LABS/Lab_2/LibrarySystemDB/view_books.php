<?php
// view_books.php
$conn = new mysqli("localhost", "root", "", "LibrarySystemDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "
    SELECT B.book_id, B.book_title, A.author_name, B.genre, B.price
    FROM Books B
    INNER JOIN Authors A ON B.author_id = A.author_id
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Books</title>
</head>
<body>
    <h2>Books List</h2>
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th><th>Title</th><th>Author</th><th>Genre</th><th>Price ($)</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= htmlspecialchars($row['book_id']) ?></td>
            <td><?= htmlspecialchars($row['book_title']) ?></td>
            <td><?= htmlspecialchars($row['author_name']) ?></td>
            <td><?= htmlspecialchars($row['genre']) ?></td>
            <td><?= htmlspecialchars($row['price']) ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
