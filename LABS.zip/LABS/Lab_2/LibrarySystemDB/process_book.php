<?php
// process_book.php
$conn = new mysqli("localhost", "root", "", "LibrarySystemDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get and sanitize input
$book_title = trim($_POST['book_title']);
$author_id = (int)$_POST['author_id'];
$genre = trim($_POST['genre']);
$price = $_POST['price'];

if (empty($book_title) || empty($author_id) || empty($genre) || !is_numeric($price)) {
    die("Please fill all fields correctly.");
}

$stmt = $conn->prepare("INSERT INTO Books (book_title, author_id, genre, price) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sisd", $book_title, $author_id, $genre, $price);

if ($stmt->execute()) {
    echo "Book added successfully! <br><a href='view_books.php'>View Books</a>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
