<?php
$host = 'localhost';
$db = 'EmployeeDB';
$user = 'root'; // Default XAMPP user
$pass = '';     // Default XAMPP password (usually blank)

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
