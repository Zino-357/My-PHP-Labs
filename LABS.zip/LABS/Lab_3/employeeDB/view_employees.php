<?php
// view_employees.php
$conn = new mysqli("localhost", "root", "", "EmployeeDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "
    SELECT E.emp_id, E.emp_name, E.emp_salary, D.dept_name, D.dept_location
    FROM Employee E
    INNER JOIN Department D ON E.emp_dept_id = D.dept_id
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Employees</title>
</head>
<body>
    <h2>Employee List</h2>
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th><th>Name</th><th>Salary</th><th>Department</th><th>Location</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['emp_id'] ?></td>
            <td><?= htmlspecialchars($row['emp_name']) ?></td>
            <td>$<?= $row['emp_salary'] ?></td>
            <td><?= htmlspecialchars($row['dept_name']) ?></td>
            <td><?= htmlspecialchars($row['dept_location']) ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
