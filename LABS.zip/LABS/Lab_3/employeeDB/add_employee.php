<?php
// add_employee.php
$conn = new mysqli("localhost", "root", "", "EmployeeDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$departments = $conn->query("SELECT * FROM Department");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
</head>
<body>
    <h2>Add New Employee</h2>
    <form action="process_employee.php" method="POST">
        <label for="emp_name">Employee Name:</label><br>
        <input type="text" id="emp_name" name="emp_name" required><br><br>

        <label for="emp_salary">Employee Salary:</label><br>
        <input type="number" id="emp_salary" name="emp_salary" step="0.01" required><br><br>

        <label for="emp_dept_id">Department:</label><br>
        <select id="emp_dept_id" name="emp_dept_id" required>
            <option value="">Select Department</option>
            <?php while ($row = $departments->fetch_assoc()) { ?>
                <option value="<?= $row['dept_id'] ?>"><?= htmlspecialchars($row['dept_name']) ?> - <?= htmlspecialchars($row['dept_location']) ?></option>
            <?php } ?>
        </select><br><br>

        <input type="submit" value="Add Employee">
    </form>
</body>
</html>
