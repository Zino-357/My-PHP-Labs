<?php
// process_employee.php
$conn = new mysqli("localhost", "root", "", "EmployeeDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$emp_name = trim($_POST['emp_name']);
$emp_salary = $_POST['emp_salary'];
$emp_dept_id = $_POST['emp_dept_id'];

if (empty($emp_name) || empty($emp_salary) || empty($emp_dept_id) || !is_numeric($emp_salary)) {
    die("Please fill all fields correctly.");
}

$stmt = $conn->prepare("INSERT INTO Employee (emp_name, emp_salary, emp_dept_id) VALUES (?, ?, ?)");
$stmt->bind_param("sdi", $emp_name, $emp_salary, $emp_dept_id);

if ($stmt->execute()) {
    echo "Employee added successfully! <br><a href='view_employees.php'>View Employees</a>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
