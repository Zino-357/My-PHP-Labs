<?php
$conn = new mysqli("localhost", "root", "", "StudentDB");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM Students WHERE student_id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Student deleted successfully. <a href='view_students.php'>Back to list</a>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
