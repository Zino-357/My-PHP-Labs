<?php
$conn = new mysqli("localhost", "root", "", "StudentDB");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM Students");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Students</title>
</head>
<body>
    <h2>All Students</h2>
    <a href="add_student.php">Add New Student</a>
    <br><br>
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['student_id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['phone_number']) ?></td>
            <td>
                <a href="edit_student.php?id=<?= $row['student_id'] ?>">Edit</a> | 
                <a href="delete_student.php?id=<?= $row['student_id'] ?>" onclick="return confirm('Delete this student?');">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
