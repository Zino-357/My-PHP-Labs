<!DOCTYPE html>
<html>
<head>
    <title>Add New Student</title>
</head>
<body>
    <h2>Add Student</h2>
    <form action="insert_student.php" method="POST">
        <label>Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Phone Number:</label><br>
        <input type="text" name="phone_number" required><br><br>

        <input type="submit" value="Add Student">
    </form>
    <br>
    <a href="view_students.php">View All Students</a>
</body>
</html>
