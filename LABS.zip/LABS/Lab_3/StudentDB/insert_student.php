<?php
$conn = new mysqli("localhost", "root", "", "StudentDB");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$phone_number = trim($_POST['phone_number']);

if (empty($name) || empty($email) || empty($phone_number)) {
    die("All fields are required.");
}

$stmt = $conn->prepare("INSERT INTO Students (name, email, phone_number) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $phone_number);

if ($stmt->execute()) {
    echo "Student added successfully. <a href='view_students.php'>View Students</a>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
