<?php
$conn = new mysqli("localhost", "root", "", "StudentDB");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM Students WHERE student_id = $id");
if ($result->num_rows !== 1) {
    die("Student not found.");
}
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
</head>
<body>
    <h2>Edit Student</h2>
    <form action="update_student.php" method="POST">
        <input type="hidden" name="student_id" value="<?= $row['student_id'] ?>">

        <label>Name:</label><br>
        <input type="text" name="name" value="<?= htmlspecialchars($row['name']) ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= htmlspecialchars($row['email']) ?>" required><br><br>

        <label>Phone Number:</label><br>
        <input type="text" name="phone_number" value="<?= htmlspecialchars($row['phone_number']) ?>" required><br><br>

        <input type="submit" value="Update Student">
    </form>
    <br>
    <a href="view_students.php">Back to Student List</a>
</body>
</html>
