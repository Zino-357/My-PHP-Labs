<?php
require_once 'auth_check.php';
auth_check();

$conn = new mysqli("localhost", "root", "", "LibraryDB");

$sql = "SELECT * FROM books";
$result = $conn->query($sql);
?>

<h2>Library Catalog</h2>
<table border="1">
    <tr>
        <th>Title</th><th>Author</th><th>Price</th><th>Genre</th><th>Year</th><th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($row['author'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($row['genre'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($row['year'], ENT_QUOTES, 'UTF-8') ?></td>
            <td>
                <a href="edit_book.php?id=<?= $row['book_id'] ?>">Edit</a> |
                <a href="delete_book.php?id=<?= $row['book_id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<a href="add_book.php">Add New Book</a> |
<a href="home.php">Back to Home</a>

<?php $conn->close(); ?>
