<?php
require_once 'auth_check.php';
auth_check();
require_once 'csrf_token.php'; // Ensure token is generated
?>

<h2>Add New Book</h2>
<form action="process_book.php" method="post">
    <label>Title:</label><input type="text" name="title" required><br>
    <label>Author:</label><input type="text" name="author" required><br>
    <label>Price:</label><input type="number" step="0.01" name="price" required><br>
    <label>Genre:</label><input type="text" name="genre" required><br>
    <label>Year:</label><input type="number" name="year" required><br>

    <!-- CSRF Token -->
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

    <input type="submit" value="Add Book">
</form>

<a href="view_books.php">Back to Library</a>
