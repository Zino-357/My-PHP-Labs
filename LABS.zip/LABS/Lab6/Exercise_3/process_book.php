<?php
session_start();
require_once 'db_connect.php'; // DB connection
require_once 'auth_check.php';
auth_check();

// CSRF Check
if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) ||
    $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("❌ CSRF token validation failed.");
}

// Get and sanitize form inputs
$title = trim($_POST['title']);
$author = trim($_POST['author']);
$price = $_POST['price'];
$genre = trim($_POST['genre']);
$year = $_POST['year'];

// Prepared statement to prevent SQL Injection
$stmt = $conn->prepare("INSERT INTO Books (title, author, price, genre, year) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssdi", $title, $author, $price, $genre, $year);

if ($stmt->execute()) {
    echo "✅ Book added successfully.<br>";
} else {
    echo "❌ Error adding book: " . $stmt->error;
}

echo "<br><a href='view_books.php'>Back to Library</a>";
$stmt->close();
$conn->close();
?>
