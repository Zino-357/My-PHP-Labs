<?php
require_once 'auth_check.php';
auth_check();

$conn = new mysqli("localhost", "root", "", "LibraryDB");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs using htmlspecialchars (optional for defense-in-depth)
    $title  = htmlspecialchars(trim($_POST['title']));
    $author = htmlspecialchars(trim($_POST['author']));
    $price  = $_POST['price'];
    $genre  = htmlspecialchars(trim($_POST['genre']));
    $year   = $_POST['year'];

    // ✅ Use Prepared Statement (Prevents SQL Injection)
    $stmt = $conn->prepare("INSERT INTO books (title, author, price, genre, year) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsi", $title, $author, $price, $genre, $year);

    if ($stmt->execute()) {
        echo "✅ Book added successfully! <a href='view_books.php'>View Books</a>";
    } else {
        echo "❌ Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<h2>Add Book</h2>
<form method="post">
    Title: <input type="text" name="title" required><br><br>
    Author: <input type="text" name="author" required><br><br>
    Price: <input type="number" name="price" step="0.01"><br><br>
    Genre: <input type="text" name="genre"><br><br>
    Year: <input type="number" name="year"><br><br>
    <input type="submit" value="Add Book">
</form>
<a href="home.php">Back to Home</a>
