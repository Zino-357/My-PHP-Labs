<?php
$host = "localhost";     // or "127.0.0.1"
$user = "root";          // default XAMPP username
$pass = "";              // default password for XAMPP is empty
$db   = "LibraryDB";     // Make sure this database exists

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
