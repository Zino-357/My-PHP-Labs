<?php
// home.php
require_once 'Auto_check.php';
?>

<h2>Welcome, <?php echo htmlspecialchars($_SESSION['user']['username']); ?>!</h2>
<p>Your email is: <?php echo htmlspecialchars($_SESSION['user']['email']); ?></p>
<a href="logout.php">Logout</a>
