<?php
// Include this file at the top of every protected page except:
// home.php, login.php, register.php, google_login.php, google_auth.php

require_once 'auth_check.php';
auth_check();
