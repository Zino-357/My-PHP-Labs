<?php
session_start();
?>

<h2>Welcome to the Library System</h2>

<?php if (isset($_SESSION['user'])): ?>
    <p>Hello, <?= htmlspecialchars($_SESSION['user']['username']) ?>!</p>
    <a href="library.php">Go to Library</a> |
    <a href="profile.php">Profile</a> |
    <a href="logout.php">Logout</a>
<?php else: ?>
    <p>You are not logged in.</p>
    <a href="login.php">Login</a> |
    <a href="register.php">Register</a> |
    <a href="google_login.php">Login with Google</a>
<?php endif; ?>
