<?php
require_once 'auth_check.php';
auth_check();
require_once 'auth_db.php';
?>

<h2>Library Catalog</h2>

<?php
$result = $conn->query("SELECT * FROM books");

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='5'>
            <tr><th>Title</th><th>Author</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".htmlspecialchars($row['title'])."</td>
                <td>".htmlspecialchars($row['author'])."</td>
                <td>".htmlspecialchars($row['status'])."</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No books available.";
}
?>

<a href="home.php">Back to Home</a>
