<?php
require_once 'auth_check.php';
auth_check();

$conn = new mysqli("localhost", "root", "", "LibraryDB");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM books WHERE book_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: view_books.php");
exit();
