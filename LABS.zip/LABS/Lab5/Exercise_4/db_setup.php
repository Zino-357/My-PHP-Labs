<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "LibraryDB";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create DB if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");

// Select DB
$conn->select_db($dbname);

// Create Books Table
$sql = "CREATE TABLE IF NOT EXISTS books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    price DECIMAL(10,2),
    genre VARCHAR(100),
    year INT
)";

if ($conn->query($sql) === TRUE) {
    echo "Books table ready.";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
