<?php
require_once 'auth_check.php';
auth_check();

$conn = new mysqli("localhost", "root", "", "LibraryDB");
$result = $conn->query("SELECT * FROM books");
?>

<h2>All Books</h2>
<a href="add_book.php">Add New Book</a> |
<a href="home.php">Home</a> |
<a href="logout.php">Logout</a>
<br><br>

<table border="1" cellpadding="5">
    <tr>
        <th>ID</th><th>Title</th><th>Author</th><th>Price</th><th>Genre</th><th>Year</th><th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['book_id'] ?></td>
        <td><?= htmlspecialchars($row['title']) ?></td>
        <td><?= htmlspecialchars($row['author']) ?></td>
        <td><?= htmlspecialchars($row['price']) ?></td>
        <td><?= htmlspecialchars($row['genre']) ?></td>
        <td><?= htmlspecialchars($row['year']) ?></td>
        <td>
            <a href="edit_book.php?id=<?= $row['book_id'] ?>">Edit</a> |
            <a href="delete_book.php?id=<?= $row['book_id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
