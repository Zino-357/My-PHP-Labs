<?php
require_once 'auth_check.php';
auth_check();

$conn = new mysqli("localhost", "root", "", "LibraryDB");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $book = $conn->query("SELECT * FROM books WHERE book_id = $id")->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id     = $_POST['id'];
    $title  = $_POST['title'];
    $author = $_POST['author'];
    $price  = $_POST['price'];
    $genre  = $_POST['genre'];
    $year   = $_POST['year'];

    $stmt = $conn->prepare("UPDATE books SET title=?, author=?, price=?, genre=?, year=? WHERE book_id=?");
    $stmt->bind_param("ssdssi", $title, $author, $price, $genre, $year, $id);
    $stmt->execute();

    echo "Book updated successfully! <a href='view_books.php'>Back to list</a>";
    exit();
}
?>

<h2>Edit Book</h2>
<form method="post">
    <input type="hidden" name="id" value="<?= $book['book_id'] ?>">
    Title: <input type="text" name="title" value="<?= $book['title'] ?>" required><br><br>
    Author: <input type="text" name="author" value="<?= $book['author'] ?>" required><br><br>
    Price: <input type="number" step="0.01" name="price" value="<?= $book['price'] ?>"><br><br>
    Genre: <input type="text" name="genre" value="<?= $book['genre'] ?>"><br><br>
    Year: <input type="number" name="year" value="<?= $book['year'] ?>"><br><br>
    <input type="submit" value="Update Book">
</form>
