<?php
require_once 'vendor/autoload.php';
require_once 'auth_db.php';
session_start();

$client = new Google_Client();
$client->setClientId('YOUR_GOOGLE_CLIENT_ID');
$client->setClientSecret('YOUR_GOOGLE_CLIENT_SECRET');
$client->setRedirectUri('http://localhost/google_auth.php');

if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $client->setAccessToken($token);

    // Get profile info
    $oauth2 = new Google_Service_Oauth2($client);
    $google_account_info = $oauth2->userinfo->get();
    $email = $google_account_info->email;
    $name = $google_account_info->name;

    // Check if user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        // Insert new Google user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, '')");
        $stmt->bind_param("ss", $name, $email);
        $stmt->execute();
        $user_id = $stmt->insert_id;
    } else {
        $user = $result->fetch_assoc();
    }

    // Log in the user
    $_SESSION["user"] = [
        "username" => $name,
        "email" => $email
    ];

    header("Location: home.php");
    exit;
} else {
    echo "Invalid access.";
}
