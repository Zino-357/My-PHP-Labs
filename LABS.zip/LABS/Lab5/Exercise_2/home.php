<?php
require_once 'auth_check.php';
?>

<h2>Welcome to the Library System</h2>
<p>Hello, <?= htmlspecialchars($_SESSION['user']['username']) ?>!</p>
<a href="profile.php">View Profile</a> | 
<a href="logout.php">Logout</a>
